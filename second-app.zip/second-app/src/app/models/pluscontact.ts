export class Pluscontact {
    firstName: string;
    lastName: string;
    phoneNumber: number;
    email: string;
}

// id: number;
// firstName: string;
// lastName: string;
// phoneNumber: number;
// email: string;