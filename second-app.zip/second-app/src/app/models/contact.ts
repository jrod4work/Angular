export class Contacts3 {
    id: number;
    firstName: string;
    lastName: string;
    phoneNumber: number;
    email: string;
}


