import { Levl } from '../types/levl.enum';


export class Skill2class {
    id: number;
  name: string;
  level: string;
}
